import chisel3._
import chisel3.util._

// 定义一个名为 RegisterFile 的模块
class RegisterFile extends Module {
    val io = IO(new Bundle {
        // 输入端口定义
        val RS1 = Input(UInt(5.W))         // 第一个操作数的索引
        val RS2 = Input(UInt(5.W))         // 第二个操作数的索引
   

        val Reg_WB = Input(Bool())         // 写回信号
        val WB_data = Input(UInt(32.W))    // 写回的数据
        
        val RS1_out = Output(UInt(32.W))   // 第一个操作数的值
        val RS2_out = Output(UInt(32.W))   // 第二个操作数的值
    })

    // 定义一个包含32个32位寄存器的寄存器文件
    val registers = RegInit(VecInit((0 until 32).map(i => i.U(32.W))))

    // 从寄存器文件中读取第一个操作数的值
    io.RS1_out := Mux(io.RS1 === 0.U, 0.U, registers(io.RS1))
    // 从寄存器文件中读取第二个操作数的值
    io.RS2_out := Mux(io.RS2 === 0.U, 0.U, registers(io.RS2))

    // 当写回信号有效时，将写回的数据写入相应的寄存器
    when(io.Reg_WB) {
        registers(io.RS1) := Mux(io.RS1 === 0.U, 0.U, io.WB_data)
        registers(io.RS2) := Mux(io.RS2 === 0.U, 0.U, io.WB_data)
    }
}
