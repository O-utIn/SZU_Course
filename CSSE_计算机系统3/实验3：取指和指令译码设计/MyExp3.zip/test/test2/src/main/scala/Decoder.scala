package mydesign

import chisel3._
import chisel3.util._
import chisel3.util.BitPat
import Instructions._

class JieMaProperties extends Bundle {
	val Instr_word = Input(UInt(32.W))
	val add_op     = Output(UInt(1.W))
	val sub_op     = Output(UInt(1.W))
	val lw_op      = Output(UInt(1.W))
	val sw_op      = Output(UInt(1.W))
	val nop        = Output(UInt(1.W))
}

class JieMa extends Module {
	val io = IO(new JieMaProperties())
	val JieMaProperties = ListLookup(io.Instr_word, default, map)
	io.add_op := JieMaProperties(0)
	io.sub_op := JieMaProperties(1)
	io.lw_op  := JieMaProperties(2)
	io.sw_op  := JieMaProperties(3)
	io.nop    := JieMaProperties(4)
}
