package mydesign

import chisel3._
import chisel3.util._
import chisel3.util.BitPat

// 定义 Instructions 对象，包含了指令和操作的设置
object Instructions {

    // 定义加法操作的开和关
    val startAdd  = 1.U(1.W)
    val closeAdd = 0.U(1.W)
    
    // 定义减法操作的开和关
    val startSub  = 1.U(1.W)
    val closeSUb = 0.U(1.W)

    // 定义加载操作的开和关
    val startLw  = 1.U(1.W)
    val closeLW  = 0.U(1.W)
    
    // 定义存储操作的开和关
    val startSw  = 1.U(1.W)
    val closeSw  = 0.U(1.W)
    
    // 定义空操作的开和关
    val startNop  = 1.U(1.W)
    val closeNop = 0.U(1.W)

    // 定义具体的指令格式，使用 BitPat 进行匹配
    def addCode = BitPat("b000000???????????????00000100000")
    def subCode = BitPat("b000000???????????????00000100010")
    def lwCode  = BitPat("b100011??????????????????????????")
    def swCOde  = BitPat("b101011??????????????????????????")
    
    // 定义默认的操作码设置
    val default = List(closeAdd, closeSUb, closeLW, closeSw, startNop)

    // 定义指令与操作码的映射关系
    val map = Array(
        // 指令       add_op   sub_op   lw_op   sw_op   nop
        addCode -> List(startAdd,  closeSUb, closeLW, closeSw, closeNop),
        subCode -> List(closeAdd, startSub,  closeLW, closeSw, closeNop),
        lwCode  -> List(closeAdd, closeSUb, startLw,  closeSw, closeNop),
        swCOde  -> List(closeAdd, closeSUb, closeLW, startSw,  closeNop)
    )
}
