package mydesign

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DecoderTest extends AnyFlatSpec with ChiselScalatestTester {
	behavior of "JieMa"
	it should "pass" in {
		test(new JieMa).withAnnotations(Seq(WriteVcdAnnotation)) {c=>
			c.io.Instr_word.poke("b000000_00010_00011_00001_00000_100000".U)
			

			c.clock.step(1)
			c.io.Instr_word.poke("b000000_00101_00110_00000_00000_100010".U)
			
			c.clock.step(1)
			c.io.Instr_word.poke("b100011_00101_00010_00000_00000_110010".U)
			

			c.clock.step(1)
			c.io.Instr_word.poke("b10101100101000100000000000110100".U)
			

			c.clock.step(1)
			c.io.Instr_word.poke("b00001100001000100000000000110010".U)
				c.clock.step(1)
		}
	}
}
